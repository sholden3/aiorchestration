export const environment = {
  production: false,
  apiUrl: '' // Will use default from ConfigService
};